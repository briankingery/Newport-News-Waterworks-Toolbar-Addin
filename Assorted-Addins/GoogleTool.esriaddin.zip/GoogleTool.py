#   https://geonet.esri.com/thread/162023

import arcpy  
import pythonaddins  
import functools  
import os  
import threading  
import webbrowser  
arcpy.env.overwriteOutput = True  
  
  
def run_in_other_thread(function):  
    @functools.wraps(function)  
    def fn_(*args, **kwargs):  
        thread = threading.Thread(target=function, args=args, kwargs=kwargs)  
        thread.start()  
        thread.join()  
    return fn_  
openbrowser = run_in_other_thread(webbrowser.open)  
  
  
class GoogleExtension(object):  
    """Implementation for GoogleTool_addin.extension10 (Extension)"""  
    def activeViewChanged(self):  
        mxd = arcpy.mapping.MapDocument('current')  
        active_view = mxd.activeView  
        # tool1 is the tool ID (without the namespace prefix)  
        if active_view == 'PAGE_LAYOUT':  
            tool.enabled = False  
        else:  
            tool.enabled = True  
        arcpy.RefreshActiveView()  
        return  
  
  
class MapChannels(object):  
    """Implementation for GoogleTool_gmcaddin.tool (Tool)"""  
    def __init__(self):  
        self.enabled = True  
        self.shape = "NONE"   
    def onMouseUpMap(self, x, y, button, shift):  
        mxd = arcpy.mapping.MapDocument("CURRENT")  
        df = arcpy.mapping.ListDataFrames(mxd)[0]  
        dfsr = df.spatialReference  
        if len(dfsr.type) > 0:  
            pass  
        else:  
            msgbox = pythonaddins.MessageBox('No Coordinate System','Oops!',0)  
            print msgbox  
            sys.exit("Unknown projection")  
        in_memory = "in_memory"  
        fcname = "pnt_name4444aj"  
        #x,y = [2424419.971, 864749.537]  
        fc = arcpy.CreateFeatureclass_management(in_memory,fcname,"POINT","","DISABLED","DISABLED",dfsr)  
        rows = arcpy.da.InsertCursor(fc,["SHAPE@XY"])  
        xy = (x,y)  
        rows.insertRow([xy])  
        del rows  
        sr = 'GEOGCS["GCS_North_American_1927",DATUM["D_North_American_1927",SPHEROID["Clarke_1866",6378206.4,294.9786982]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]'  
        for row in arcpy.da.SearchCursor(fc, ["SHAPE@XY"],"",sr):  
            adx,ady = row[0]  
            #print("{0}, {1}".format(adx, ady))  
        for lyr in arcpy.mapping.ListLayers(mxd, "", df):  
            if lyr.name == fcname:  
                arcpy.mapping.RemoveLayer(df, lyr)  
        url = "http://data.mapchannels.com/mm/dual2/map.htm?x=" +  str(adx) + "&y="+ str(ady) + "&z=16&xb=" + str(adx) + "&yb="+  str(ady) + "&bar=1&mw=1&gm=0&ve=2&sv=1"#&svb="+ String(computeAngle2(startPt,lastPnt))  
        openbrowser(url)  
  
  
        del mxd,df,dfsr,in_memory,fc,xy,sr,row,url 
